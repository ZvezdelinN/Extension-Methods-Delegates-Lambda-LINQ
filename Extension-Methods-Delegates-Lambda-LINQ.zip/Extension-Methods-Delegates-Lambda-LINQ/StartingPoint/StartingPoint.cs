﻿namespace StartingPoint
{
    using System;
    using Extensions;
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;
    using System.Linq;

    public class StartingPoint
    {
        public static void Main(string[] args)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("dhjuhdjkdshgjkhfkd");
            StringBuilder str = sb.Substring(2, 4);
            Console.WriteLine(str);

            List<Student> lst = new List<Student>() { new Student("Zvezdelin", "Chucharkov", 40), new Student("Petar", "Petrov", 52), new Student("Ivan", "Atanasov", 23), new Student("Mariela", "Nikolaeva", 13),
                                                      new Student("Dimitar","Bochkov",58), new Student("Maria","Bochkova",55), new Student("Zornitca","Bochkova",38)};

            List<List<Student>> result = new List<List<Student>>();
                        
            result.Add(lst.FindAll(x => string.Compare(x.FirstName, x.LastName) < 0)); //Problem 3. First before last
            
            result.Add(lst.FindAll(x => (x.Age >= 18 && x.Age <= 24)));//Problem 4. Age range

            List<Student> ordered = new List<Student>();

            ordered = lst.OrderBy(x => x.FirstName).ToList();
            ordered.Reverse();
            result.Add(ordered); //Problem 5. Order students

            ordered = lst.OrderBy(x => x.FirstName).ThenBy(x => x.LastName).ToList();

            List<List<int>> intResult =new List<List<int>>();

            List<int> numbers = new List<int>();
            for (int i = 0; i < 100; i++)
            {
                numbers.Add(i);
            }

            intResult.Add(numbers.FindAll(x => x % 7 == 0 && x % 3 == 0));


        }
    }
}
