﻿namespace StartingPoint.Extensions
{
    using System;
    using System.Collections;
    using System.Text;

    public static class StringBuilderExtension
    {
        public static StringBuilder Substring(this StringBuilder sb, int index, int length) 
        {
            StringBuilder result = new StringBuilder();

            if (index < 0 || index > sb.Length)
            {
                throw new IndexOutOfRangeException("The index is out of range");
            }

            if (length < 0 || length + index > sb.Length)
            {
                throw new IndexOutOfRangeException("The length is out of range");
            }

            for (int i = index; i < length + index; i++)
            {
                result.Append(sb[i]);   
            }
            
            return result;
        }

        public static void MyMethod(int index)
        {
            Console.WriteLine(index);
        }
    }
}
