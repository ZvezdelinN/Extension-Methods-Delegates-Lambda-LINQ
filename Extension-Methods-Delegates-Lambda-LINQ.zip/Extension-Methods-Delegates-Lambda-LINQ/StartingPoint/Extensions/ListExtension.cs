﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StartingPoint.Extensions
{
    public static class ListExtension
    {
        //public static List<Student> OrderBy(this List<Student> lst)
        //{
        //    List<Student> result = lst.OrderBy(x => x.FirstName);
        //}
    }
}
